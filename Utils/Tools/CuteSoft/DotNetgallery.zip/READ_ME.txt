=========================================================================================
   How to Install DotNetGallery Examples
=========================================================================================

Unzip the zip file and create a virtual directory or website pointing it to the 'DotNetGallery\Web' folder.

NOTE:

DotNetGallery creates thumbnail files in the folders where images are stored.
You should ensure that the ASPNET user (NetworkService in Windows Server 2003) has read/write permission to this specified folder.
