using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;
using System.Security.Principal;
using System.Data;
using System.Data.SqlClient;

namespace SamplePortal 
{
	/// <summary>
	/// Global Application Handler
	/// </summary>
	public class Global : System.Web.HttpApplication
	{
		private System.ComponentModel.IContainer components = null;

		static Global()
		{
			CuteChat.ChatProvider.Instance=new SamplePortal.Components.SampleProvider();
			CuteChat.ChatSystem.Start(new CuteChat.AppSystem());
		}

		public Global()
		{
			InitializeComponent();
		}
		

		public static String ConnectionString
		{
			get
			{
				return System.Configuration.ConfigurationSettings.AppSettings["ConnectionString"];
			}
		}

		/// <summary>
		/// if LastOnlineTime before this time, then offline
		/// </summary>
		public static DateTime OnlineTimeoutTime
		{
			get
			{
				Int32 iTimeoutSecond = Int32.Parse(System.Configuration.ConfigurationSettings.AppSettings["OnlineTimeout"]);
				return DateTime.Now.AddSeconds(0 - iTimeoutSecond);
			}
		}
		
		protected void Application_Start(Object sender, EventArgs e)
		{

		}
 
		protected void Session_Start(Object sender, EventArgs e)
		{

		}

		protected void Application_BeginRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_EndRequest(Object sender, EventArgs e)
		{

		}

		protected void Application_AuthenticateRequest(Object sender, EventArgs e)
		{
			if (this.Request.IsAuthenticated)
			{
				GenericPrincipal currUser = new GenericPrincipal(this.User.Identity, GetRolesOfUser(this.User.Identity.Name));
				this.Context.User = currUser;

				Global.UpdateLastLoginTime(currUser.Identity.Name, DateTime.Now);
			}
		}

		protected void Application_Error(Object sender, EventArgs e)
		{

		}

		protected void Session_End(Object sender, EventArgs e)
		{
		}

		protected void Application_End(Object sender, EventArgs e)
		{

		}

		public static void UpdateLastLoginTime(String username, DateTime lastLoginTime)
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("update sampleUsers set LastLoginTime=@LastLoginTime where Username=@Username", conn);

			SqlParameter paraLastLoginTime = cmd.Parameters.Add("@LastLoginTime", SqlDbType.DateTime);
			paraLastLoginTime.Value = lastLoginTime;

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			try
			{
				conn.Open();
				cmd.ExecuteNonQuery();
			}
			finally
			{
				conn.Close();
			}
		}

		public static String[] GetRolesOfUser(String username)
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("select RoleName from sampleUserRole where Username=@Username", conn);

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			try
			{
				conn.Open();

				SqlDataReader reader = cmd.ExecuteReader();
				ArrayList roles = new ArrayList();
				while(reader.Read())
				{
					roles.Add(reader.GetString(0));
				}
				
				return (String[]) roles.ToArray(typeof(String));
			}
			finally
			{
				conn.Close();
			}
		}

		public static String[] GetAllRoles()
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("select RoleName from sampleRoles order by RoleName", conn);

			try
			{
				conn.Open();
				SqlDataReader reader = cmd.ExecuteReader();
				ArrayList result = new ArrayList();
				while(reader.Read())
				{
					result.Add(reader.GetString(0));
				}
				return (String[]) result.ToArray(typeof(String));
			}
			finally
			{
				conn.Close();
			}
		}

		public static void AddUserToRole(String roleName, String username)
		{
			if (Global.IsUserInRole(roleName, username))
			{
				return;
			}

			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("Insert into sampleUserRole (Username, RoleName) values (@Username, @RoleName)", conn);

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			SqlParameter paraRoleName = cmd.Parameters.Add("@RoleName", SqlDbType.NVarChar);
			paraRoleName.Value = roleName;

			try
			{
				conn.Open();
				cmd.ExecuteNonQuery();
			}
			catch
			{
				return;
			}
			finally
			{
				conn.Close();
			}
		}

		public static void RemoveUserFromRole(String roleName, String username)
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("delete from sampleUserRole where (Username=@Username) and (RoleName=@RoleName)", conn);

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			SqlParameter paraRoleName = cmd.Parameters.Add("@RoleName", SqlDbType.NVarChar);
			paraRoleName.Value = roleName;

			try
			{
				conn.Open();
				cmd.ExecuteNonQuery();
			}
			finally
			{
				conn.Close();
			}
		}

		public static void RemoveUserFromAllRoles(String username)
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("delete from sampleUserRole where (Username=@Username)", conn);

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			try
			{
				conn.Open();
				cmd.ExecuteNonQuery();
			}
			finally
			{
				conn.Close();
			}
		}

		public static Boolean IsUserInRole(String roleName, String username)
		{
			SqlConnection conn = new SqlConnection(Global.ConnectionString);
			SqlCommand cmd = new SqlCommand("select COUNT(Username) from sampleUserRole where (Username=@Username) and (RoleName=@RoleName)", conn);

			SqlParameter paraUsername = cmd.Parameters.Add("@Username", SqlDbType.NVarChar);
			paraUsername.Value = username;

			SqlParameter paraRoleName = cmd.Parameters.Add("@RoleName", SqlDbType.NVarChar);
			paraRoleName.Value = roleName;

			try
			{
				conn.Open();
				return Convert.ToInt32(cmd.ExecuteScalar())>0;
			}
			finally
			{
				conn.Close();
			}
		}
			
		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support
		/// do not modify this method
		/// </summary>
		private void InitializeComponent()
		{    
			this.components = new System.ComponentModel.Container();
		}
		#endregion
	}
}

