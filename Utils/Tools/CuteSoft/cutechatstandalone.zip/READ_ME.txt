=================================================================
   How to Install Cute Chat /Cute WebMessenger
=================================================================

Installation instructions can be found at Document/Deployment.htm
