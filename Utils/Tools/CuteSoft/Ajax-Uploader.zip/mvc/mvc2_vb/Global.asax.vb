﻿Public Class MvcApplication
	Inherits System.Web.HttpApplication

	Shared Sub RegisterRoutes(ByVal routes As RouteCollection)
		routes.IgnoreRoute("{resource}.axd/{*pathInfo}")
		routes.MapRoute( _
		 "Default", _
		 "{controller}/{action}/{id}", _
		 New With {.controller = "", .action = "", .id = ""} _
		)

	End Sub

	Sub Application_Start()
		AreaRegistration.RegisterAllAreas()

		RegisterRoutes(RouteTable.Routes)
	End Sub
End Class
