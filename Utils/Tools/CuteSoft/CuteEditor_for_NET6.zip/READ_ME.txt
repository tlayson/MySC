============================================
   How to Install Cute Editor for .NET
============================================

Installation instructions can be found at Deployment.htm.